/* 
	Basado en Codigo de Ricardo Estrada/Purdy  
*/

DROP TABLE IF EXISTS Demos.Dates

CREATE TABLE Demos.Dates
(
      [Date]				DATE NOT NULL
    , [Year]				AS   DATEPART(YEAR,[Date])
    , FullyMonthID			AS   DATEPART(YEAR,[Date])*100+DATEPART(month,[Date])
	, FullMonth				AS   CAST(CONCAT(DATEPART(YEAR,[Date]), ' - ', (FORMAT([Date],'MMMM','en-us'))) AS VARCHAR(20))  
    , MonthID				AS   DATEPART(MONTH,[Date])
    , [Month]				AS   CAST((FORMAT([Date],'MMMM','en-us'))  AS VARCHAR(20))  
    , DayID					AS   DATEPART(day,[Date]) 
    , [Weekday]				AS   CAST((DATEPART(WEEKDAY,[Date]))  AS VARCHAR(20))  
    , [Day]					AS   CAST((FORMAT([Date],'dddd','en-us')) AS VARCHAR(20))  
    , FullWeekID			AS   DATEPART(YEAR,[Date])*100+DATEPART(WEEK,[Date])
	, FullWeek				AS   CAST(CONCAT(DATEPART(YEAR,[Date]), ' - W', RIGHT('0'+ CAST(DATEPART(WEEK,[Date]) AS VARCHAR(2)),2)) AS VARCHAR(20))  
    , WeekID				AS   DATEPART(WEEK,[Date])  
    , [WeekName]			AS   CAST(CONCAT('W',RIGHT('0'+ CAST(DATEPART(WEEK,[Date]) AS VARCHAR(2)),2)) AS VARCHAR(20))  
    , QuarterID				AS   DATEPART(QUARTER,[Date])
    , [Quarter]				AS   CAST(CONCAT('Q', DATEPART(QUARTER,[Date]))  AS VARCHAR(20)) 
    , FullQuarterID			AS   DATEPART(YEAR,[Date])*100+DATEPART(QUARTER,[Date])
    , FullQuarter			AS   CAST(CONCAT(YEAR([Date]), '-Q', DATEPART(QUARTER,[Date]))  AS VARCHAR(20)) 

    , CONSTRAINT PK_Dates 
	   PRIMARY KEY CLUSTERED ([Date] ASC) 
);

GO
CREATE OR ALTER   PROCEDURE Demos.InsertDates(@StartYear INT = 2018, @NumberOfYears INT = 1)
AS
	SET NOCOUNT, XACT_ABORT ON;
	TRUNCATE TABLE Demos.Dates;

	;WITH Dates AS (		  
		SELECT DATEFROMPARTS(COALESCE(@StartYear, YEAR(GETDATE())), 1, 1) AS [Date]
		UNION ALL
		SELECT DATEADD(DAY, 1, [Date]) AS [Date]
		FROM Dates
		WHERE DATEADD(DAY, 1, [Date]) <= DATEFROMPARTS(@StartYear+@NumberOfYears, 12, 31)
						AND [DATE] >  DATEFROMPARTS(1900, 1, 1)
	)
	INSERT INTO Demos.Dates
	SELECT [Date]
	FROM Dates
	OPTION (MAXRECURSION 0);
GO
EXEC Demos.InsertDates 2000, 40
SELECT * FROM Demos.Dates
