SELECT SalesOrderID, 
       CAST(DATEADD(MONTH, 6, DATEADD(YEAR, 7, OrderDate)) AS DATE) AS OrderDate, 
       CAST(DATEADD(MONTH, 6, DATEADD(YEAR, 7, DueDate)) AS DATE) AS DueDate, 
       CAST(DATEADD(MONTH, 6, DATEADD(YEAR, 7, ShipDate)) AS DATE) AS ShipDate,
       ---, OnlineOrderFlag, SalesOrderNumber
       --, PurchaseOrderNumber, AccountNumber 
       CustomerID, 
       SalesPersonID, 
       TerritoryID, 
       --BillToAddressID, 
       --ShipToAddressID, 
       --ShipMethodID, 
       --CreditCardID,
       --, CreditCardApprovalCode
       --, CurrencyRateID 
       SubTotal, 
       TaxAmt, 
       Freight, 
       TotalDue
FROM Sales.SalesOrderHeader AS OH
ORDER BY OrderDate DESC
