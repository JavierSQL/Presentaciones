CREATE OR ALTER VIEW Demos.Individuals
AS 
    WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/IndividualSurvey' AS sv)
    , BaseIndividuos AS (
    SELECT 
        C.CustomerID,
        RTRIM(
            CONCAT(
                COALESCE(p.FirstName + ' ', '')
                , COALESCE(p.MiddleName + ' ', '')
                , COALESCE(p.LastName, '')
            )) AS FullName
        ,at.Name AS AddressType
        ,a.AddressLine1
        ,a.AddressLine2
        ,a.City
        ,StateProvinceName = sp.Name
        ,a.PostalCode
        ,CountryRegionName = cr.Name
        ,p.EmailPromotion
        , C.value('sv:Occupation[1]','varchar(50)') AS Occupation
        , C.value('sv:Education[1]','varchar(50)') AS Education
        , C.value('sv:HomeOwnerFlag[1]','bit') AS HomeOwnerFlag
        , C.value('sv:NumberCarsOwned[1]','int') AS NumberCarsOwned
        , C.value('sv:Gender[1]','char(1)') AS Gender
        , C.value('sv:MaritalStatus[1]','char(1)') AS MaritalStatus
        , C.value('sv:BirthDate[1]','date') AS BirthDate
        , CAST(DATEADD(MONTH, 6, DATEADD(YEAR, 5, 
            C.value('sv:DateFirstPurchase[1]','date'))) AS DATE) AS DateFirstPurchase
        , ROW_NUMBER() OVER(PARTITION BY C.CustomerID
            ORDER BY CASE at.Name WHEN 'Home'  THEN 1   
                                    ELSE 4 END, bea.AddressTypeID ) AS RSel
    FROM Sales.Customer AS c
    JOIN Person.Person p
        ON c.PersonID = p.BusinessEntityID
        INNER JOIN Person.BusinessEntityAddress bea 
        ON bea.BusinessEntityID = p.BusinessEntityID 
        INNER JOIN Person.Address a 
        ON a.AddressID = bea.AddressID
        INNER JOIN Person.StateProvince sp 
        ON sp.StateProvinceID = a.StateProvinceID
        INNER JOIN Person.CountryRegion cr 
        ON cr.CountryRegionCode = sp.CountryRegionCode
        INNER JOIN Person.AddressType at 
        ON at.AddressTypeID = bea.AddressTypeID
        LEFT OUTER JOIN Person.EmailAddress ea
        ON ea.BusinessEntityID = p.BusinessEntityID
        LEFT OUTER JOIN Person.PersonPhone pp
        ON pp.BusinessEntityID = p.BusinessEntityID
        LEFT OUTER JOIN Person.PhoneNumberType pnt
        ON pnt.PhoneNumberTypeID = pp.PhoneNumberTypeID
    CROSS APPLY p.Demographics.nodes('/sv:IndividualSurvey') AS SV(C)
    WHERE c.PersonID IS NOT NULL
        AND c.CustomerID IN (SELECT  oh.CustomerID
            FROM Sales.SalesOrderHeader AS OH)
    )
    SELECT CustomerID, FullName, AddressType, AddressLine1, AddressLine2, City, StateProvinceName, PostalCode
        , CountryRegionName, EmailPromotion, Occupation, Education, HomeOwnerFlag, NumberCarsOwned, Gender
        , MaritalStatus, BirthDate, DateFirstPurchase
    FROM BaseIndividuos
    WHERE RSel=1;
GO
SELECT TOP 20 * FROM Demos.Individuals